package com.halajabban;

public interface FrameObserver {
    public void update();
}
