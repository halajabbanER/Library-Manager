/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.halajabban;

import com.halajabban.GUI.LoginFrame;
import com.halajabban.Models.User;
import com.halajabban.database.Database;

public class Libmanager {
    public static User authenticatedUser;
    public static void main(String[] args) {
        Database.instantiateDatabase();

        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }
}