package com.halajabban.Models;

import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 * @author Dell
 */
public class FineTableModel extends DefaultTableModel {

    private final List<Fine> fines;
    private final String[] columnNames = {"Id", "Book Title", "User Name", "Fine Amount", "Status"};
    private final Class<?>[] columnTypes = {Integer.class, String.class, String.class, String.class};

    public FineTableModel(List<Fine> fines) {
        this.fines = fines;
    }

    @Override
    public int getRowCount() {
        return fines == null ? 0 : fines.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }


    @Override
    public boolean isCellEditable(int row, int column) {
        return new boolean[]{false, false, false, true, true}[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 0 -> Integer.class;
            case 1, 2, 3, 4 -> String.class;
            default -> Object.class;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Fine fine = fines.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> fine.getId();
            case 1 -> fine.getLoan().getBook().getTitle();
            case 2 -> fine.getLoan().getUser().getName();
            case 3 -> fine.getAmount();
            case 4 -> fine.isPaid() ? "1" : "0";
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Fine fine = fines.get(rowIndex);
        switch (columnIndex) {
            case 3 -> fine.setAmount(Double.parseDouble((String) aValue));
            case 4 -> fine.setPaid(aValue.equals("1"));
        }
        fine.save();
        System.out.println("Fine updated: " + fine);
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}
