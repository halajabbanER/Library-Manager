package com.halajabban.Models;

import com.halajabban.Helper;
import com.halajabban.database.BaseDataAccessObject;

import java.sql.ResultSet;
import java.util.List;
import java.util.Objects;

public class Fine extends BaseDataAccessObject<Fine> {
    private int id;
    private int loanId;
    private double amount;
    private boolean paid;
    private Loan loan;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        if (loan != null) {
            this.loan = loan;
            this.loanId = loan.getId();
        }
        this.loan = new Loan().getById(loanId);
    }

    // Mapping a ResultSet to a Fine instance
    @Override
    protected Fine apply(ResultSet resultSet) {
        try {
            Fine fine = new Fine();
            fine.setId(resultSet.getInt("id"));
            fine.setLoanId(resultSet.getInt("loan_id"));
            fine.setAmount(resultSet.getDouble("amount"));
            fine.setPaid(resultSet.getBoolean("paid"));
            fine.setLoan(new Loan().getById(fine.getLoanId()));
            return fine;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Fetch all fines
    @Override
    public List<Fine> getAll(String queryFilter) {
        return executeQueryList("SELECT * FROM fines " + queryFilter, this::apply);
    }


    public void calculateOverdue() {
        List<Loan> loans = new Loan().getAll("WHERE status = 'loaned'");
        for (Loan loan : loans) {
            if (loan.getDueDate().before(Helper.DateFromString(Helper.getCurrentDate()))) {
                Fine fine = new Fine();
                fine.setLoan(loan);
                fine.setAmount(10 * Helper.daysDifference(loan.getDueDate(), Objects.requireNonNull(Helper.DateFromString(Helper.getCurrentDate()))));
                fine.setPaid(false);
                fine.save();
                loan.setStatus("overdue");
                loan.save();
            }
        }
    }

    // Fetch a fine by ID
    @Override
    public Fine getById(int id) {
        return executeQuery("SELECT * FROM fines WHERE id = " + id, this::apply);
    }

    // Add a new fine
    @Override
    public Integer add(Fine entity) {
        String query = String.format(
                "INSERT INTO fines (loan_id, amount, paid) VALUES (%d, '%s', %b)",
                entity.getLoanId(), String.valueOf(entity.getAmount()).replace(',','.'), entity.isPaid()
        );
        return executeInsert(query);
    }

    // Update an existing fine
    @Override
    public void update(Fine entity) {
        String query = String.format(
                "UPDATE fines SET loan_id=%d, amount=%.2f, paid=%b WHERE id=%d",
                entity.getLoanId(), entity.getAmount(), entity.isPaid(), entity.getId()
        );
        executeUpdate(query);
    }

    public void save() {
        if (id == 0) {
            add(this);
        } else {
            update(this);
        }
    }

    // Delete a fine by ID
    @Override
    public void delete(int id) {
        executeUpdate("DELETE FROM fines WHERE id = " + id);
    }


    @Override
    public String toString() {
        return "Fine{" +
                "id=" + id +
                ", loanId=" + loanId +
                ", amount=" + amount +
                ", paid=" + paid +
                ", loan=" + loan +
                '}';
    }
}