package com.halajabban.Models;

import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 * @author Dell
 */
public class UserTableModel extends DefaultTableModel {

    public enum Role {
        LIBRARIAN, MEMBER
    }
    private final List<User> users;
    private final String[] columnNames = {"Id", "Name", "Email", "Phone", "Role"};
    private final Class<?>[] columnTypes = {Integer.class, String.class, String.class, String.class, Role.class};

    public UserTableModel(List<User> users) {
        this.users = users;
    }

    @Override
    public int getRowCount() {
        return users == null ? 0 : users.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }


    @Override
    public boolean isCellEditable(int row, int column) {
        return column != 0;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 0 -> Integer.class;
            case 1, 2, 3, 4 -> String.class;
            default -> Object.class;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        User user = users.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> user.getId();
            case 1 -> user.getName();
            case 2 -> user.getEmail();
            case 3 -> user.getPhone();
            case 4 -> user.getRole() != null ? Role.valueOf(user.getRole().toUpperCase()) : "";
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        User user = users.get(rowIndex);

        switch (columnIndex) {
            case 1:
                user.setName((String) aValue);
                break;
            case 2:
                user.setEmail((String) aValue);
                break;
            case 3:
                user.setPhone((String) aValue);
                break;
            case 4:
                user.setRole(aValue.toString().toLowerCase());
                break;
        }
        user.save();
        System.out.println("User updated: " + user);
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}
