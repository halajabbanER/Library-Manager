package com.halajabban.Models;

import com.halajabban.Helper;

import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 * @author Dell
 */
public class LoanTableModel extends DefaultTableModel {

    private final List<Loan> loans;
    private final String[] columnNames = {"Id", "User Name", "Book Title", "Loan Date", "Due Date", "Return Date", "Status"};
    private final Class<?>[] columnTypes = {Integer.class, String.class, String.class, String.class, String.class, String.class, String.class};

    public LoanTableModel(List<Loan> loans) {
        this.loans = loans;
    }

    @Override
    public int getRowCount() {
        return loans == null ? 0 : loans.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }


    @Override
    public boolean isCellEditable(int row, int column) {
        return new boolean[]{false, false, false, false, false, true, true}[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 0 -> Integer.class;
            case 1, 2, 3, 4 -> String.class;
            default -> Object.class;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Loan loan = loans.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> loan.getId();
            case 1 -> loan.getUser().getName();
            case 2 -> loan.getBook().getTitle();
            case 3 -> loan.getLoanDate().toString();
            case 4 -> loan.getDueDate().toString();
            case 5 -> loan.getReturnDate() == null ? "" : loan.getReturnDate().toString();
            case 6 -> loan.getStatus();
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Loan loan = loans.get(rowIndex);
        switch (columnIndex) {
            case 6 -> loan.setStatus((String) aValue);
            case 5 -> loan.setReturnDate(Helper.DateFromString((String) aValue));
        }
        loan.save();
        System.out.println("Loan updated: " + loan);
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}
