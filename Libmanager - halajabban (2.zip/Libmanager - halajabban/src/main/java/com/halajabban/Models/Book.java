package com.halajabban.Models;

import com.halajabban.database.BaseDataAccessObject;

import java.sql.ResultSet;
import java.util.List;
import java.util.Objects;

public class Book extends BaseDataAccessObject<Book> {
    private int id;
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private int publishedYear;
    private int copiesAvailable;

    public Book() {
    }

    public Book(int id, String title, String author, String isbn, String genre, int publishedYear, int copiesAvailable) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.publishedYear = publishedYear;
        this.copiesAvailable = copiesAvailable;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getPublishedYear() {
        return publishedYear;
    }

    public void setPublishedYear(int publishedYear) {
        this.publishedYear = publishedYear;
    }

    public int getCopiesAvailable() {
        return copiesAvailable;
    }

    public void setCopiesAvailable(int copiesAvailable) {
        this.copiesAvailable = copiesAvailable;
    }

    // Mapping a ResultSet to a Book instance
    @Override
    protected Book apply(ResultSet resultSet) {
        try {
            Book book = new Book();
            book.setId(resultSet.getInt("id"));
            book.setTitle(resultSet.getString("title"));
            book.setAuthor(resultSet.getString("author"));
            book.setIsbn(resultSet.getString("isbn"));
            book.setGenre(resultSet.getString("genre"));
            book.setPublishedYear(resultSet.getInt("published_year"));
            book.setCopiesAvailable(resultSet.getInt("copies_available"));
            return book;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Fetch all books
    @Override
    public List<Book> getAll(String queryFilter) {
        return executeQueryList("SELECT * FROM books " + queryFilter, this::apply);
    }

    // Fetch a book by ID
    @Override
    public Book getById(int id) {
        return executeQuery("SELECT * FROM books WHERE id = " + id, this::apply);
    }

    // Add a new book
    @Override
    public Integer add(Book entity) {
        String query = String.format(
                "INSERT INTO books (title, author, isbn, genre, published_year, copies_available) " +
                        "VALUES ('%s', '%s', '%s', '%s', %d, %d)",
                entity.getTitle(), entity.getAuthor(), entity.getIsbn(),
                entity.getGenre(), entity.getPublishedYear(), entity.getCopiesAvailable()
        );
        return executeInsert(query);
    }

    // Update an existing book
    @Override
    public void update(Book entity) {
        String query = String.format(
                "UPDATE books SET title='%s', author='%s', isbn='%s', genre='%s', published_year=%d, copies_available=%d " +
                        "WHERE id=%d",
                entity.getTitle(), entity.getAuthor(), entity.getIsbn(),
                entity.getGenre(), entity.getPublishedYear(), entity.getCopiesAvailable(), entity.getId()
        );
        executeUpdate(query);
    }

    public void save() {
        if (!this.title.isEmpty() && !this.author.isEmpty() && !this.isbn.isEmpty() && !this.genre.isEmpty()) {
            if (this.id == 0) {
                this.add(this);
            } else {
                this.update(this);
            }
        }
    }

    // Delete a book by ID
    @Override
    public void delete(int id) {
        executeUpdate("DELETE FROM books WHERE id = " + id);
    }

    public void addCopies() {
        this.copiesAvailable++;
        this.update(this);
    }

    public void removeCopies() {
        this.copiesAvailable--;
        this.update(this);
    }

    @Override
    public String toString() {
        return isbn + ": " + title + " by " + author;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Book book = (Book) obj;
        return id == book.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}