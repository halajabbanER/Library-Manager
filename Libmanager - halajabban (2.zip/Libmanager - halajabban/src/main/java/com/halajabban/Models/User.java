package com.halajabban.Models;

import com.halajabban.database.BaseDataAccessObject;

import java.sql.ResultSet;
import java.util.List;

public class User extends BaseDataAccessObject<User> {
    private int id;
    private String name;
    private String email;
    private String password;
    private String phone;
    private String role;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    protected User apply(ResultSet resultSet) {
        try {
            User user = new User();
            user.setId(resultSet.getInt("id"));
            user.setName(resultSet.getString("name"));
            user.setEmail(resultSet.getString("email"));
            user.setPassword(resultSet.getString("password"));
            user.setPhone(resultSet.getString("phone"));
            user.setRole(resultSet.getString("role"));
            return user;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public User authenticate(String email, String password) {
        return executeQuery(
                String.format("SELECT * FROM users WHERE email = '%s' AND password = '%s'", email, password),
                this::apply
        );
    }

    @Override
    public List<User> getAll(String queryFilter) {
        return executeQueryList("SELECT * FROM users " + queryFilter, this::apply);
    }

    public List<User> getAll() {
        return getAll("");
    }

    @Override
    public User getById(int id) {
        return executeQuery("SELECT * FROM users WHERE id = " + id, this::apply);
    }
    
    
    public User getByEmail(String email) {
        return executeQuery("SELECT * FROM users WHERE email = '" + email + "'", this::apply);
    }

    @Override
    public Integer add(User entity) {
        String query = String.format(
                "INSERT INTO users (name, email, password, phone, role) VALUES ('%s', '%s', '%s', '%s','%s')",
                entity.getName(), entity.getEmail(), entity.getPassword(), entity.getPhone(), entity.getRole()
        );
        return executeInsert(query);
    }

    public void save() {
        if (!this.name.isEmpty() && !this.email.isEmpty() && !this.password.isEmpty() && !this.phone.isEmpty()) {
            if (this.id == 0) {
                this.add(this);
            } else {
                this.update(this);
            }
        }
    }

    @Override
    public void update(User entity) {
        String query = String.format(
                "UPDATE users SET name='%s', email='%s', password='%s', phone='%s', role='%s' WHERE id=%d",
                entity.getName(), entity.getEmail(), entity.getPassword(), entity.getPhone(), entity.getRole(), entity.getId()
        );
        executeUpdate(query);
    }

    @Override
    public void delete(int id) {
        executeUpdate("DELETE FROM users WHERE id = " + id);
    }


    @Override
    public String toString(){
        return name + " (" + email + ")";
    }
}