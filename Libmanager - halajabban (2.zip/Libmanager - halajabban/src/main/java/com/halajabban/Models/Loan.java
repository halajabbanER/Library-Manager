package com.halajabban.Models;

import com.halajabban.Helper;
import com.halajabban.database.BaseDataAccessObject;

import java.sql.ResultSet;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Loan extends BaseDataAccessObject<Loan> {
    private int id;
    private int userId;
    private int bookId;
    private Date loanDate;
    private Date dueDate;
    private Date returnDate;
    private String status;
    private User user;
    private Book book;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public Date getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(Date loanDate) {
        this.loanDate = loanDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Book getBook() {
        if(book == null){
            book = new Book().getById(bookId);
        }
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    // Mapping a ResultSet to a Loan instance
    @Override
    protected Loan apply(ResultSet resultSet) {
        try {
            Loan loan = new Loan();
            loan.setId(resultSet.getInt("id"));
            loan.setUserId(resultSet.getInt("user_id"));
            loan.setBookId(resultSet.getInt("book_id"));
            loan.setLoanDate(resultSet.getDate("loan_date"));
            loan.setDueDate(resultSet.getDate("due_date"));
            loan.setReturnDate(resultSet.getDate("return_date"));
            loan.setStatus(resultSet.getString("status"));
            loan.setUser(new User().getById(loan.getUserId()));
            loan.setBook(new Book().getById(loan.getBookId()));
            return loan;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Fetch all loans
    @Override
    public List<Loan> getAll(String queryFilter) {
        return executeQueryList("SELECT * FROM loans " + queryFilter, this::apply);
    }

    // Fetch a loan by ID
    @Override
    public Loan getById(int id) {
        return executeQuery("SELECT * FROM loans WHERE id = " + id, this::apply);
    }

    // Add a new loan
    @Override
    public Integer add(Loan entity) {
        String returnDate = entity.getReturnDate() == null ? "NULL" : "'" + Helper.DateToString(entity.getReturnDate()) + "'";
        String query = String.format(
                "INSERT INTO loans (user_id, book_id, loan_date, due_date, return_date, status) " +
                        "VALUES (%d, %d, '%s', '%s', %s, '%s')",
                entity.getUserId(), entity.getBookId(),
                Helper.DateToString(entity.getLoanDate()), Helper.DateToString(entity.getDueDate()),
                returnDate,
                entity.getStatus()
        );
        return executeInsert(query);
    }

    // Update an existing loan
    @Override
    public void update(Loan entity) {
        String returnDate = entity.getReturnDate() == null ? "NULL" : "'" + Helper.DateToString(entity.getReturnDate()) + "'";
        String query = String.format(
                "UPDATE loans SET user_id=%d, book_id=%d, loan_date='%s', due_date='%s', " +
                        "return_date=%s, status='%s' WHERE id=%d",
                entity.getUserId(), entity.getBookId(), Helper.DateToString(entity.getLoanDate()), Helper.DateToString(entity.getDueDate()),
                returnDate, entity.getStatus(), entity.getId()
        );
        executeUpdate(query);
    }

    public void save() {
        if (id == 0) {
            add(this);
        } else {
            update(this);
        }
    }

    // Delete a loan by ID
    @Override
    public void delete(int id) {
        executeUpdate("DELETE FROM loans WHERE id = " + id);
    }

    @Override
    public String toString() {
        return "Book: " + book.getTitle() + " - User: " + user.getName() + " (" + status + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Loan book = (Loan) obj;
        return id == book.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public void returnBook() {
        this.status = "returned";
        this.returnDate =Helper.DateFromString(Helper.getCurrentDate());
        this.getBook().addCopies();
        save();
        new Fine().calculateOverdue();
    }
}