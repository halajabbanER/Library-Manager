package com.halajabban.Models;

import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 * @author Dell
 */
public class BookTableModel extends DefaultTableModel {

    private final List<Book> books;
    private final String[] columnNames = {"Id", "Title", "Author", "ISBN", "Genre", "Published Year", "Copies Available"};
    private final Class<?>[] columnTypes = {Integer.class, String.class, String.class, String.class, String.class, Integer.class, Integer.class};

    public BookTableModel(List<Book> books) {
        this.books = books;
    }

    @Override
    public int getRowCount() {
        return books == null ? 0 : books.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }


    @Override
    public boolean isCellEditable(int row, int column) {
        return column != 0;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 0 -> Integer.class;
            case 1, 2, 3, 4 -> String.class;
            default -> Object.class;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Book book = books.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> book.getId();
            case 1 -> book.getTitle();
            case 2 -> book.getAuthor();
            case 3 -> book.getIsbn();
            case 4 -> book.getGenre();
            case 5 -> book.getPublishedYear();
            case 6 -> book.getCopiesAvailable();
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Book book = books.get(rowIndex);

        switch (columnIndex) {
            case 1:
                book.setTitle((String) aValue);
                break;
            case 2:
                book.setAuthor((String) aValue);
                break;
            case 3:
                book.setIsbn((String) aValue);
                break;
            case 4:
                book.setGenre((String) aValue);
                break;
            case 5:
                book.setPublishedYear(Integer.parseInt((String) aValue));
                break;
            case 6:
                book.setCopiesAvailable(Integer.parseInt((String) aValue));
                break;
        }
        book.save();
        System.out.println("Book updated: " + book);
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}
