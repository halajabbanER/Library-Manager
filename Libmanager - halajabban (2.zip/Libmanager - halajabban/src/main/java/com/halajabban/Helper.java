package com.halajabban;

import com.halajabban.Models.User;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.stream.Collectors;

public class Helper {

    public static String readFileFromInputStream(String filePath) {
        InputStream inputStream = Objects.requireNonNull(Libmanager.class.getClassLoader().getResourceAsStream(filePath));
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream))) {
            return bufferedReader.lines().collect(Collectors.joining(System.lineSeparator()));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "The file " + filePath + " could not be read.", "Error", JOptionPane.ERROR_MESSAGE);
            return "";
        }
    }

    public static User getAuthenticatedUser() {
        return Libmanager.authenticatedUser;
    }

    public static void setAuthenticatedUser(User user) {
        Libmanager.authenticatedUser = user;
    }

    public static boolean isLoggedIn() {
        return Libmanager.authenticatedUser != null;
    }

    public static boolean validatePassword(String password) {
        String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
        return password.matches(pattern);
    }

    public static String getCurrentDate() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return df.format(date);
    }

    public static boolean isNumeric(String publishedYear) {
        return publishedYear.matches("\\d+");
    }

    public static Date DateFromString(String date) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd").parse(date);
        } catch (Exception e) {
            return null;
        }
    }

    public static int daysDifference(Date date1, Date date2) {
        long diff = date2.getTime() - date1.getTime();
        return (int) (diff / (24 * 60 * 60 * 1000));
    }

    public static String DateToString(Date date) {
        if(date == null) {
            return "";
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public static String getFutureDate(int days) {
        Date date = new Date();
        long time = date.getTime();
        time += (long) days * 24 * 60 * 60 * 1000;
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date(time));
    }
}
