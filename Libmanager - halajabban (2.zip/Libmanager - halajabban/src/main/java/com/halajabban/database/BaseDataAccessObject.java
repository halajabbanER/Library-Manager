package com.halajabban.database;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public abstract class BaseDataAccessObject<T> {

    protected abstract T apply(ResultSet resultSet);

    public abstract List<T> getAll(String queryFilter);

    public abstract T getById(int id);

    public abstract Integer add(T entity);

    public abstract void update(T entity);

    public abstract void delete(int id);

    public int count(String queryFilter) {
        String query = "SELECT COUNT(*) FROM " + getTableName() + queryFilter;
        try (Connection connection = Database.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the query", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
        return 0;
    }

    private String getTableName() {
        return switch (this.getClass().getSimpleName()) {
            case "Book" -> "books";
            case "Fine" -> "fines";
            case "Loan" -> "loans";
            case "User" -> "users";
            default -> "";
        };
    }


    protected T executeQuery(String query, Function<ResultSet, T> mapper) {
        try (Connection connection = Database.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return mapper.apply(resultSet);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the query", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
        return null;
    }

    protected List<T> executeQueryList(String query, Function<ResultSet, T> mapper) {
        List<T> results = new ArrayList<>();
        try (Connection connection = Database.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                results.add(mapper.apply(resultSet));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the query", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
        return results;
    }

    protected void executeUpdate(String query) {
        try (Connection connection = Database.getConnection();
             Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the query", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
    }

    protected int executeInsert(String query) {
        int generatedKey = 0;
        try (Connection connection = Database.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    generatedKey = rs.getInt(1);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the query", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }

        return generatedKey;
    }
}