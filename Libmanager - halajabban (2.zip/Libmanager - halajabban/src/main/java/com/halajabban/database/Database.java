package com.halajabban.database;


import com.halajabban.Helper;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Database {

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "hala2211";
    private static final String DATABASE_NAME = "library_manager";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "CREATE DATABASE IF NOT EXISTS `" + DATABASE_NAME + "`";
            statement.executeUpdate(sql);
            connection.setCatalog(DATABASE_NAME);
            return connection;
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL JDBC Driver not found", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not connect to the database", "Database connection Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Could not close the connection", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void instantiateDatabase() {
        createDatabase();
    }

    private static void createDatabase() {
        String sqlSchema = Helper.readFileFromInputStream("sql/schema.sql");
        executeSqlScript(sqlSchema);
    }

    private static void executeSqlScript(String script) {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()
        ) {
            for (String sqlStatement : script.split(";")) {
                if (!sqlStatement.trim().isEmpty()) {
                    statement.execute(sqlStatement);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Could not execute the SQL script", "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
    }
}

