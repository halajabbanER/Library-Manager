-- Create the database
CREATE DATABASE if not exists library_manager;
USE library_manager;

-- Table: users
CREATE TABLE IF NOT EXISTS users
(
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(255)                 NOT NULL,
    email      VARCHAR(255)                 NOT NULL UNIQUE,
    password   VARCHAR(255)                 NOT NULL,
    phone      VARCHAR(20),
    role       ENUM ('librarian', 'member') DEFAULT 'member',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table: books
CREATE TABLE IF NOT EXISTS books
(
    id               INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(255) NOT NULL,
    author           VARCHAR(255) NOT NULL,
    isbn             VARCHAR(20)  NOT NULL UNIQUE,
    genre            VARCHAR(100),
    published_year   YEAR,
    copies_available INT       DEFAULT 0,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table: loans
CREATE TABLE IF NOT EXISTS loans
(
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT  NOT NULL,
    book_id     INT  NOT NULL,
    loan_date   DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE,
    status      ENUM ('loaned', 'returned', 'overdue') DEFAULT 'loaned',
    created_at  TIMESTAMP                              DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP                              DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
);

-- Table: fines (for overdue loans)
CREATE TABLE IF NOT EXISTS fines
(
    id         INT AUTO_INCREMENT PRIMARY KEY,
    loan_id    INT            NOT NULL,
    amount     DECIMAL(10, 2) NOT NULL,
    paid       BOOLEAN   DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES loans (id) ON DELETE CASCADE
);